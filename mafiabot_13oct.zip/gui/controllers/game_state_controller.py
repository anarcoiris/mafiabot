class GameStateController:
    def __init__(self, engine: GameEngine):
        self.engine = engine
        self.game = None
        # Event callbacks - sin Tkinter
        self.on_event = None

    def resolve_night(self) -> List[GameEvent]:
        """Solo lógica, sin UI"""
        events = self.engine.resolve_night(self.game)
        # Notificar via callback agnóstico
        if self.on_event:
            for event in events:
                self.on_event(event)
        return events

    # Sin timers aquí - esos van en asyncio o scheduler externo
    def register_chat_message(self, sender_id, text, is_private=False):
        msg = ChatMessage(sender_id, text, is_private)
        self.event_bus.publish(msg)

class GameEventBus:
    """Event bus agnóstico thread-safe"""
    def __init__(self):
        self.subscribers = defaultdict(list)

    def subscribe(self, event_type: str, callback):
        self.subscribers[event_type].append(callback)

    def publish(self, event: GameEvent):
        """Thread-safe"""
        for callback in self.subscribers[event.event_type]:
            callback(event)

class ChatMessage:
    timestamp: int
    sender_id: int
    recipient_id: Optional[int]  # None = público
    text: str
    is_private: bool
