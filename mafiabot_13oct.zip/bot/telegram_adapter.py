# bot/telegram_adapter.py
class TelegramAdapter(GameInterface):
    """Implementación para Telegram."""
    def __init__(self, bot):
        self.bot = bot

    async def send_message(self, recipient_id, text):
        await self.bot.send_message(recipient_id, text)
